create function postgis_scripts_installed() returns text
    immutable
    language sql
as
$$ SELECT trim('3.5.0'::text || $rev$ d2c3ca4 $rev$) AS version $$;

alter function postgis_scripts_installed() owner to postgres;

