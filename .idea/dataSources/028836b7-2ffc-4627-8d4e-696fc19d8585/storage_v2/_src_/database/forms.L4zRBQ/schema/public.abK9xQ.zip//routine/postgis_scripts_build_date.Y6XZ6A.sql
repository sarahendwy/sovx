create function postgis_scripts_build_date() returns text
    immutable
    language sql
as
$$SELECT '2024-11-21 00:00:00'::text AS version$$;

alter function postgis_scripts_build_date() owner to postgres;

