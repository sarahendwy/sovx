create function st_force3d(geom geometry, zvalue double precision DEFAULT 0.0) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language sql
as
$$SELECT public.ST_Force3DZ($1, $2)$$;

alter function st_force3d(geometry, double precision) owner to postgres;

