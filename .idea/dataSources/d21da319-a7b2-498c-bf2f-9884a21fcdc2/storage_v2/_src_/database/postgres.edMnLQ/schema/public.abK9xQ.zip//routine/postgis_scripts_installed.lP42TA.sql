create function postgis_scripts_installed() returns text
    immutable
    language sql
as
$$ SELECT trim('3.6.0dev'::text || $rev$ 3.5.0-21-g77bcee793 $rev$) AS version $$;

alter function postgis_scripts_installed() owner to postgres;

