create function st_geomfromgeojson(json) returns geometry
    immutable
    strict
    parallel safe
    cost 500
    language sql
as
$$SELECT public.ST_GeomFromGeoJson($1::text)$$;

alter function st_geomfromgeojson(json) owner to postgres;

