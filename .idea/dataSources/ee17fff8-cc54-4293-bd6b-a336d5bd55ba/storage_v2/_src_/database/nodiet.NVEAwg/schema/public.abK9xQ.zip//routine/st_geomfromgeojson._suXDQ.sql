create function st_geomfromgeojson(jsonb) returns geometry
    immutable
    strict
    parallel safe
    cost 500
    language sql
as
$$SELECT public.ST_GeomFromGeoJson($1::text)$$;

alter function st_geomfromgeojson(jsonb) owner to postgres;

