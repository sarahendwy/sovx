create view report_pos_order
            (id, nbr_lines, date, product_qty, price_sub_total, price_total, total_discount, average_price,
             delay_validation, order_id, partner_id, state, user_id, company_id, journal_id, product_id,
             product_categ_id, product_tmpl_id, config_id, pricelist_id, session_id, invoiced, margin)
as
SELECT min(l.id)                              AS id,
       count(*)                               AS nbr_lines,
       s.date_order                           AS date,
       sum(l.qty)                             AS product_qty,
       sum(l.qty * l.price_unit /
           CASE COALESCE(s.currency_rate, 0::numeric)
               WHEN 0 THEN 1.0
               ELSE s.currency_rate
               END)                           AS price_sub_total,
       sum(round(l.price_subtotal_incl /
                 CASE COALESCE(s.currency_rate, 0::numeric)
                     WHEN 0 THEN 1.0
                     ELSE s.currency_rate
                     END, cu.decimal_places)) AS price_total,
       sum(l.qty * l.price_unit * (l.discount / 100::numeric) /
           CASE COALESCE(s.currency_rate, 0::numeric)
               WHEN 0 THEN 1.0
               ELSE s.currency_rate
               END)                           AS total_discount,
       CASE
           WHEN sum(l.qty * u.factor) = 0::numeric THEN NULL::numeric
           ELSE sum(l.qty * l.price_unit /
                    CASE COALESCE(s.currency_rate, 0::numeric)
                        WHEN 0 THEN 1.0
                        ELSE s.currency_rate
                        END) / sum(l.qty * u.factor)
           END                                AS average_price,
       sum(to_char(date_trunc('day'::text, s.date_order) - date_trunc('day'::text, s.create_date),
                   'DD'::text)::integer)      AS delay_validation,
       s.id                                   AS order_id,
       s.partner_id,
       s.state,
       s.user_id,
       s.company_id,
       s.sale_journal                         AS journal_id,
       l.product_id,
       pt.categ_id                            AS product_categ_id,
       p.product_tmpl_id,
       ps.config_id,
       s.pricelist_id,
       s.session_id,
       s.account_move IS NOT NULL             AS invoiced,
       sum(l.price_subtotal - COALESCE(l.total_cost, 0::numeric) /
                              CASE COALESCE(s.currency_rate, 0::numeric)
                                  WHEN 0 THEN 1.0
                                  ELSE s.currency_rate
                                  END)        AS margin
FROM pos_order_line l
         JOIN pos_order s ON s.id = l.order_id
         LEFT JOIN product_product p ON l.product_id = p.id
         LEFT JOIN product_template pt ON p.product_tmpl_id = pt.id
         LEFT JOIN uom_uom u ON u.id = pt.uom_id
         LEFT JOIN pos_session ps ON s.session_id = ps.id
         LEFT JOIN res_company co ON s.company_id = co.id
         LEFT JOIN res_currency cu ON co.currency_id = cu.id
GROUP BY s.id, s.date_order, s.partner_id, s.state, pt.categ_id, s.user_id, s.company_id, s.sale_journal,
         s.pricelist_id, s.account_move, s.create_date, s.session_id, l.product_id, p.product_tmpl_id, ps.config_id;

alter table report_pos_order
    owner to "hyYCexQW4F";

