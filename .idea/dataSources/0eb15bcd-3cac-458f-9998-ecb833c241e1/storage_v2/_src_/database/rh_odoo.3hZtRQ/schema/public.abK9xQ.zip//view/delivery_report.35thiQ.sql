create view delivery_report
            (id, delivery_date, shipping_id, customer_mobile, tracking_number, product_name, sku, ordered_qty,
             date_from, date_to, warehouse_id)
as
SELECT sp.id,
       sp.date_done                                                                     AS delivery_date,
       sp.shipping_id,
       sp.partner_mobile                                                                AS customer_mobile,
       sp.awb_number                                                                    AS tracking_number,
       COALESCE(bom_product_template.name ->> 'en_US'::text, pt.name ->> 'en_US'::text) AS product_name,
       COALESCE(bom_product.default_code, pt.default_code)                              AS sku,
       COALESCE(bom_line.product_qty, sm.product_uom_qty)                               AS ordered_qty,
       NULL::timestamp without time zone                                                AS date_from,
       NULL::timestamp without time zone                                                AS date_to,
       sm.warehouse_id
FROM stock_picking sp
         JOIN stock_move sm ON sp.id = sm.picking_id
         JOIN product_product pp ON sm.product_id = pp.id
         JOIN product_template pt ON pp.product_tmpl_id = pt.id
         LEFT JOIN mrp_bom bom ON pt.id = bom.product_tmpl_id
         LEFT JOIN mrp_bom_line bom_line ON bom.id = bom_line.bom_id
         LEFT JOIN product_product bom_product ON bom_line.product_id = bom_product.id
         LEFT JOIN product_template bom_product_template ON bom_product.product_tmpl_id = bom_product_template.id
WHERE sp.state::text = 'done'::text
  AND sp.date_done >= '2025-03-24 00:00:00'::timestamp without time zone
  AND sp.date_done <= '2025-03-24 13:54:33'::timestamp without time zone
  AND sm.warehouse_id = 2
  AND sp.picking_type_id = ((SELECT stock_picking_type.id
                             FROM stock_picking_type
                             WHERE stock_picking_type.barcode::text = 'RI-DELIVERY'::text
                             LIMIT 1));

alter table delivery_report
    owner to "hyYCexQW4F";

